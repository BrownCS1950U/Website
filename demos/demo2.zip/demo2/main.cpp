#include <QCoreApplication>
#include <iostream>

// Virtual functions are a powerful tool and useful in runtime polymorphism.
// To declare a virtual function, simply add the "virtual keyword" to a function.

// Base class
class base {
public:
    virtual void virtual_function() { std::cout << "Virtual function\n"; }
    void non_virtual_function() { std::cout << "Non virtual function\n"; }
};

// Derived Class
class derived : public base {
public:
    void virtual_function() { std::cout << "Overriden virtual function\n"; }
    void non_virtual_function() { std::cout << "Overriden non virtual function\n"; }
};


// The above example is of a non-pure virtual function. A pure virtual function
// does not have an implementation in the base class, and is instead required to
// be defined in the derived class.

// To declare a pure virtual function, assign the function as 0 in the base class.

class abstract_class {
public:
    virtual void pure_virtual_function() = 0;
};

class derived_abstract_class : public abstract_class {
public:
    void pure_virtual_function() { std:: cout << "hello!\n"; }
};

// A class is abstract if it has at least one pure virtual function!


// Demo
int main(int argc, char *argv[])
{
    std::cout << "Demo - Virtual Functions and Abstract Classes!\n\n";

    // declare a derived class
    base* bptr;
    derived d;
    bptr = &d;

    // call virtual and non virtual functions
    bptr->virtual_function();
    bptr->non_virtual_function();

    std::cout << "\n";


    // declare a derived class
    abstract_class* abptr;
    derived_abstract_class da;
    abptr = &da;

    // call virtural function
    abptr->pure_virtual_function();

    return 0;
}
