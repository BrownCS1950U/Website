#ifndef ZOO_H
#define ZOO_H

#include <map>
#include <queue>
#include <memory>
#include <typeindex>
#include <typeinfo>

class Animal;

class Zoo {
public:
    Zoo();
    
    // Note 1: 'AnimalType' is just a label, it could be any name (you might see a lot of examples using 'T'). 
    // Also, you can have multiple template types, e.g. 'template <class T, class U>'

    // Note 2: Sometimes you might see 'template <typename AnimalType>' instead of 'template <class AnimalType>'. 
    // These are mostly interchangable, with the exception of some niche differences that you probably don't have to
    // worry about: https://stackoverflow.com/questions/2023977

    // Note 3: Annoyingly, we cannot place the definitions of template functions in the source (.cpp) file, for reasons
    // discussed here: https://stackoverflow.com/questions/495021
    // Option 1 is to place the definition in the header file, as we do below, but this can make the header file quite large
    // Option 2 is explicit instantiation (see the explanation under "Alternative Solution" of the top Stack Overflow answer),
    // but this is super annoying (you'd need to do one instantiation per function per class), so we don't recommend this 

    template <class AnimalType>
    void addAnimalOfType(std::shared_ptr<AnimalType> animal) {
        // static_pointer_cast will downcast to the base class without performing any
        // checks during runtime. This means that if 'animal' isn't actually a derived class of
        // the 'Animal' class, the behavior is undefined (aka a pain to debug).
        
        // dynamic_pointer_cast will perform runtime checks, and will produce a null pointer if
        // the cast is invalid, but is slower

        std::shared_ptr<Animal> castedAnimal = std::static_pointer_cast<Animal>(animal);
        
        // typeid converts the type to a type index which we can use as the key into our map
        m_animals[typeid(AnimalType)] = castedAnimal;
    }

    template <class AnimalType>
    std::shared_ptr<AnimalType> getAnimalOfType() {
        // Note: Really should first check if there is an animal of the requested type.
        // What should this function do/return if there isn't?
        
        std::shared_ptr<Animal> animal = m_animals[typeid(AnimalType)];
        return std::static_pointer_cast<AnimalType>(animal);
    }

private:
    // std::type_index allows us to use primitive or object types as keys
    std::map< std::type_index, std::shared_ptr<Animal> > m_animals;
};

#endif // ZOO_H


