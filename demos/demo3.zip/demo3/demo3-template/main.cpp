#include "animal.h"
#include "zoo.h"

void populateZoo(Zoo& zoo) {
    std::shared_ptr<Giraffe> george = std::make_shared<Giraffe>("George");
    std::shared_ptr<Elephant> elly = std::make_shared<Elephant>("Elly");
    std::shared_ptr<Penguin> penny = std::make_shared<Penguin>("Penny");
    zoo.addAnimalOfType<Giraffe>(george);
    zoo.addAnimalOfType<Elephant>(elly);
    zoo.addAnimalOfType<Penguin>(penny);
}

int main() {
    Zoo zoo = Zoo();
    populateZoo(zoo);

    // Below, we demonstrate that we have successfully accessed the derived classes
    // by calling derived class-exclusive methods

    std::shared_ptr<Giraffe> giraffe = zoo.getAnimalOfType<Giraffe>();
    giraffe->doGiraffeStuff();

    std::shared_ptr<Elephant> elephant = zoo.getAnimalOfType<Elephant>();
    elephant->doElephantStuff();

    std::shared_ptr<Penguin> penguin = zoo.getAnimalOfType<Penguin>();
    penguin->doPenguinStuff();

    return 0;
}