#include "zoo.h"
#include "animal.h"

Zoo::Zoo() {
    // empty body
}

// Normally we'd place the method definitions here, but we don't as explained in zoo.h