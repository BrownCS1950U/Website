#ifndef ANIMAL_H
#define ANIMAL_H

#include <iostream>

class Animal {
public:
    Animal(const std::string& name);

    // Virtual destructor makes this an abstract base class, enabling polymorphism
    // Refer to the relevant section in lecture 3 for more info
    virtual ~Animal() = default;

protected:
    std::string m_name;
};

// Normally each class should be in its own file, but we're just going to put these basic
// example classes in one file to save space

class Giraffe : public Animal {
public:
    Giraffe(const std::string& name);
    void doGiraffeStuff();
};

class Elephant : public Animal {
public:
    Elephant(const std::string& name);
    void doElephantStuff();
};

class Penguin : public Animal {
public:
    Penguin(const std::string& name);
    void doPenguinStuff();
};



#endif // ANIMAL_H


