#include "animal.h"

Animal::Animal(const std::string& name) 
: m_name(name)
{
    // empty body
}

Giraffe::Giraffe(const std::string& name)
: Animal(name)
{
    // empty body
}

void Giraffe::doGiraffeStuff() {
    std::cout << m_name << " the giraffe uses their long neck to eat tree leaves" << std::endl;
}

Elephant::Elephant(const std::string& name)
: Animal(name)
{
    // empty body
}

void Elephant::doElephantStuff() {
    std::cout << m_name << " the elephant uses their trunk to put fruit in their mouth" << std::endl;
}

Penguin::Penguin(const std::string& name)
: Animal(name)
{
    // empty body
}

void Penguin::doPenguinStuff() {
     std::cout << m_name << " the penguin dives in the water and catches a fish" << std::endl;
}

