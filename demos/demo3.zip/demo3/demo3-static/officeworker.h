#ifndef OFFICEWORKER_H
#define OFFICEWORKER_H

#include <iostream>
#include <string>

class OfficeWorker {
public:
    OfficeWorker();
    
    void doWork(int work);

    // Static functions are not associated with any particular instance/object of the class. See officeworker.cpp for more
    // information
    static void printNumWorkers();

private:
    const int m_id;

    // prefix "s_" indicates that this variable is static, but feel free to use whatever naming convention you're used to
    // Note that static members can only be declared in the header file: we have to define their value in the source file
    static int s_nextID;
};

#endif // OFFICEWORKER_H


