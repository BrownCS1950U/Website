#include "officeworker.h"

#include <iostream>

// Defining initial value of static member variable here in the source file
int OfficeWorker::s_nextID = 0;

OfficeWorker::OfficeWorker() 
: m_id(s_nextID)
{
    // Incrementing the static member means that the next OfficeWorker object will be constructed
    // with an ID one greater than the previous, since static members are shared amongst objects
    // of the same class. You can think of static variables as having the persistence of global variables
    // but with a constrained scope
    s_nextID++;
    std::cout << "Office worker #" << m_id << " has clocked in for the day" << std::endl;
}

void OfficeWorker::printNumWorkers() {
    // Static member functions are not associated with a specific object, so we don't use an object to call them.
    // In other words, we call this function via OfficeWorker::getNumWorkers(), not officeWorker.getNumWorkers().
    // This means that static member functions cannot reference ordinary member variables or functions (as these are 
    // associated with specific objects), but they can reference static member variables and other static member functions
    std::cout << "There are currently " <<  s_nextID << " worker(s) in the office" << std::endl;
}

void OfficeWorker::doWork(int work) {
    // Static variables declared in member functions are similar to static member variables: the variable will persist
    // between function calls, and its value will be shared amongst each instantiated object
    static int totalWorkDone = 0;
    totalWorkDone += work;
    std::cout << "Office worker #" << m_id << " did " << work << 
    " hours of work, bringing the total work done in the office to " << totalWorkDone << std::endl;
}

