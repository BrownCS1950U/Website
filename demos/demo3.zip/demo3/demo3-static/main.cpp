#include "officeworker.h"



int main() {
    OfficeWorker worker1 = OfficeWorker();
    OfficeWorker::printNumWorkers(); // note that we don't use a specific worker to call the static member function

    OfficeWorker worker2 = OfficeWorker();
    OfficeWorker::printNumWorkers();

    worker1.doWork(3);
    worker2.doWork(4);

    worker1.doWork(6);
    worker2.doWork(2);

    return 0;
}