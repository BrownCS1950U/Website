#include "car.h"

// List initialization is the only way to set the value of const members:
// "m_make = make" won't work
Car::Car(std::string make, std::string model, std::string category) 
: m_make(make), m_model(model), m_category(category)
{
    // empty body
}

// Passing by reference is preferable because the string won't be copied, but
// there is a risk that the licensePlate will be modified unexpectedly.
// Specifying that the parameter is const prevents this risk, as attempting
// to modify it will raise a compilation error
void Car::setLicensePlate(const std::string& licensePlate) {

    // Code won't even compile if the line below is uncommented
    // licensePlate = "Oops the license # has been modified!";

    m_licensePlate = licensePlate;
}

// Adding const after the parentheses prevents any member from being modified,
// even if the member isn't const
void Car::printInfo() const {
    
    // Code won't even compile if the line below is uncommented
    // m_licensePlate = "Oops the the license # has been modified!";

    std::cout << "Make: " << m_make << std::endl
    << "Model: " << m_model << std::endl
    << "Category: " << m_category << std::endl
    << "License #: " << m_licensePlate << std::endl;
}