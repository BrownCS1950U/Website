#include "car.h"

int main() {
    Car car1 = Car("Toyota", "Prius", "Sedan");
    car1.setLicensePlate("1234ABC");
    car1.printInfo();

    Car car2 = Car("Honda", "Odyssey", "Minivan");
    car2.setLicensePlate("5678DEF");
    car2.printInfo();

    return 0;
}