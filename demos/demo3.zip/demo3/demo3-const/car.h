#ifndef CAR_H
#define CAR_H

#include <iostream>
#include <string>

class Car {
public:
    Car(std::string make, std::string model, std::string category);
    
    // const function parameter: prevents the function from modifying the value of the parameter
    // (especially helpful with references since modifying a reference will modify the value outside of the function)
    void setLicensePlate(const std::string& licensePlate);

    // const member function: prevents the function from modifying any member variables
    // exception: you can use the "mutable" keyword to indicate that a member is allowed to be modified,
    // see https://en.cppreference.com/w/cpp/language/cv for more info
    void printInfo() const;

private:
    // const variable: cannot be modified after the value is set. We can set the value of const members
    // in the constructor via list initialization (see car.cpp)
    const std::string m_make; // Toyota, Honda, Ford, etc.
    const std::string m_model; // Prius, Civic, Focus, etc.
    const std::string m_category; // sedan, truck, van, etc. 
    std::string m_licensePlate;
};

#endif // CAR_H


